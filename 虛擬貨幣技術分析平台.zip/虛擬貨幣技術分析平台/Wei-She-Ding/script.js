// 虛擬貨幣技術分析平台 JavaScript
class CryptoAnalysisPlatform {
    constructor() {
        this.basePrices = {
            'BTCUSDT': 43000,
            'ETHUSDT': 2600,
            'DOGEUSDT': 0.089
        };
        
        this.cryptoNames = {
            'BTCUSDT': '比特幣 (BTC)',
            'ETHUSDT': '以太坊 (ETH)',
            'DOGEUSDT': '狗狗幣 (DOGE)'
        };
        
        this.timeframes = {
            '1m': '1分鐘',
            '5m': '5分鐘',
            '15m': '15分鐘',
            '1h': '1小時',
            '4h': '4小時',
            '1d': '1天'
        };
        
        this.currentData = null;
        this.currentIndicators = {};
        this.refreshInterval = null;
        
        this.init();
    }
    
    init() {
        console.log('初始化應用程式...');
        this.setupEventListeners();
        console.log('事件監聽器設置完成');
        
        // 確保圖表容器存在
        const plotlyContainer = document.getElementById('plotlyChartContainer');
        if (!plotlyContainer) {
            console.error('找不到 Plotly 圖表容器');
            return;
        }
        
        // 初始化時顯示 Plotly 圖表
        this.switchChart('plotly');
        console.log('圖表切換完成');
        
        // 更新數據
        this.updateData().then(() => {
            console.log('初始數據更新完成');
        }).catch(error => {
            console.error('初始數據更新失敗:', error);
        });
        
        // 初始化快速設置按鈕狀態
        this.initializeQuickSettings();
        
        // 啟動自動刷新
        this.startAutoRefresh();
        console.log('自動刷新啟動完成');
        
        console.log('初始化完成');
    }
    
    initializeQuickSettings() {
        // 設置每個滑桿對應的快速設置按鈕初始狀態
        const sliderSettings = {
            'smaPeriod': 20,
            'emaPeriod': 12,
            'rsiPeriod': 14,
            'bbPeriod': 20
        };
        
        Object.entries(sliderSettings).forEach(([sliderId, defaultValue]) => {
            const slider = document.getElementById(sliderId);
            if (slider) {
                const quickBtns = slider.parentElement.querySelectorAll('.quick-btn');
                quickBtns.forEach(btn => {
                    const btnValue = parseInt(btn.getAttribute('data-value'));
                    if (btnValue === defaultValue) {
                        btn.classList.add('active');
                    }
                });
            }
        });
    }
    
    setupEventListeners() {
        // 選擇框變更事件
        document.getElementById('symbolSelect').addEventListener('change', () => this.updateData());
        document.getElementById('timeframeSelect').addEventListener('change', () => this.updateData());
        
        // 指標切換事件
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.currentIndicators = this.calculateIndicators(this.currentData);
                this.updateChart();
                this.updateIndicatorValues();
                this.updateTradingSignals();
                
                // 更新關鍵價位標記
                setTimeout(() => {
                    this.addKeyLevelsToChart();
                }, 100);
            });
        });
        
        // 指標解釋顯示/隱藏功能
        document.querySelectorAll('.info-icon').forEach(icon => {
            icon.addEventListener('click', (e) => {
                e.stopPropagation(); // 防止觸發 label 的點擊事件
                
                const explanation = icon.parentElement.parentElement.querySelector('.indicator-explanation');
                if (explanation) {
                    const isVisible = explanation.style.display === 'block';
                    explanation.style.display = isVisible ? 'none' : 'block';
                }
            });
        });
        
        // 滑桿變更事件
        document.querySelectorAll('input[type="range"]').forEach(slider => {
            slider.addEventListener('input', (e) => {
                const valueSpan = document.getElementById(e.target.id.replace('Period', 'Value'));
                if (valueSpan) {
                    valueSpan.textContent = e.target.value;
                }
                
                // 更新快速設置按鈕狀態
                const quickBtns = e.target.parentElement.querySelectorAll('.quick-btn');
                quickBtns.forEach(btn => {
                    const btnValue = parseInt(btn.getAttribute('data-value'));
                    if (btnValue === parseInt(e.target.value)) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                });
                
                // 即時更新指標
                this.currentIndicators = this.calculateIndicators(this.currentData);
                this.updateChart();
                this.updateIndicatorValues();
                this.updateTradingSignals();
            });
        });
        
        // 圖表切換按鈕事件
        document.getElementById('plotlyChartBtn').addEventListener('click', () => {
            this.switchChart('plotly');
        });
        
        document.getElementById('tradingviewChartBtn').addEventListener('click', () => {
            this.switchChart('tradingview');
        });
        
        // 手動更新按鈕
        document.getElementById('manualUpdateBtn').addEventListener('click', () => {
            console.log('手動更新按鈕被點擊');
            this.updateData();
        });
        
        // 快速設置按鈕事件
        document.querySelectorAll('.quick-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const targetId = btn.getAttribute('data-target');
                const value = parseInt(btn.getAttribute('data-value'));
                const slider = document.getElementById(targetId);
                const valueSpan = document.getElementById(targetId.replace('Period', 'Value'));
                
                if (slider && valueSpan) {
                    // 更新滑桿值
                    slider.value = value;
                    valueSpan.textContent = value;
                    
                    // 更新按鈕狀態
                    btn.parentElement.querySelectorAll('.quick-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    
                    // 觸發指標更新
                    this.currentIndicators = this.calculateIndicators(this.currentData);
                    this.updateChart();
                    this.updateIndicatorValues();
                    this.updateTradingSignals();
                    
                    // 更新關鍵價位標記
                    setTimeout(() => {
                        this.addKeyLevelsToChart();
                    }, 100);
                    
                    console.log(`快速設置 ${targetId} 為 ${value}`);
                }
            });
        });
    }
    
    generateMockData(symbol, timeframe, limit = 500) {
        const basePrice = this.basePrices[symbol] || 1000;
        const volatility = 0.03;
        const data = [];
        
        // 計算時間間隔（分鐘）
        const intervals = { '1m': 1, '5m': 5, '15m': 15, '1h': 60, '4h': 240, '1d': 1440 };
        const intervalMinutes = intervals[timeframe] || 60;
        
        // 生成時間戳
        const now = new Date();
        const timestamps = [];
        for (let i = limit - 1; i >= 0; i--) {
            timestamps.push(new Date(now - i * intervalMinutes * 60000));
        }
        
        // 生成價格數據
        let currentPrice = basePrice;
        for (let i = 0; i < limit; i++) {
            const change = (Math.random() - 0.5) * volatility * currentPrice / 50;
            currentPrice = Math.max(currentPrice + change, currentPrice * 0.95);
            
            const open = i === 0 ? basePrice : data[i-1].close;
            const close = currentPrice;
            const high = Math.max(open, close) + Math.random() * Math.abs(close - open) * 0.3;
            const low = Math.min(open, close) - Math.random() * Math.abs(close - open) * 0.3;
            const volume = Math.random() * 10000 + 1000;
            
            data.push({
                timestamp: timestamps[i],
                open: parseFloat(open.toFixed(8)),
                high: parseFloat(high.toFixed(8)),
                low: parseFloat(low.toFixed(8)),
                close: parseFloat(close.toFixed(8)),
                volume: parseFloat(volume.toFixed(2))
            });
        }
        
        return data;
    }
    
    async fetchBinanceData(symbol, timeframe, limit = 500) {
        try {
            console.log(`嘗試獲取 ${symbol} ${timeframe} 數據...`);
            const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${timeframe}&limit=${limit}`;
            console.log('API URL:', url);
            
            const response = await fetch(url);
            console.log('API 響應狀態:', response.status);
            
            if (!response.ok) {
                throw new Error(`API request failed: ${response.status} ${response.statusText}`);
            }
            
            const rawData = await response.json();
            console.log('原始數據長度:', rawData.length);
            
            // 檢查是否為錯誤響應
            if (rawData.code && rawData.msg) {
                throw new Error(`Binance API error: ${rawData.msg}`);
            }
            
            // 轉換幣安數據格式
            const data = rawData.map(item => ({
                timestamp: new Date(item[0]), // 開盤時間
                open: parseFloat(item[1]),
                high: parseFloat(item[2]),
                low: parseFloat(item[3]),
                close: parseFloat(item[4]),
                volume: parseFloat(item[5])
            }));
            
            console.log('數據轉換完成，有效數據點:', data.length);
            return data;
        } catch (error) {
            console.error('獲取幣安數據失敗:', error);
            
            // 顯示網路連線錯誤訊息
            this.showNetworkError();
            
            // 使用模擬數據作為備用
            const mockData = this.generateMockData(symbol, timeframe, limit);
            console.log('模擬數據生成完成，數據點數量:', mockData.length);
            
            // 更新數據來源信息
            const dataSourceInfo = document.querySelector('.data-source-info');
            if (dataSourceInfo) {
                dataSourceInfo.textContent = '💡 因網路連線問題，目前使用模擬數據進行展示';
            }
            
            return mockData;
        }
    }
    
    calculateIndicators(data) {
        const indicators = {};
        
        // SMA
        if (document.getElementById('smaCheck').checked) {
            const period = parseInt(document.getElementById('smaPeriod').value);
            indicators.sma = this.calculateSMA(data, period);
        }
        
        // EMA
        if (document.getElementById('emaCheck').checked) {
            const period = parseInt(document.getElementById('emaPeriod').value);
            indicators.ema = this.calculateEMA(data, period);
        }
        
        // RSI
        if (document.getElementById('rsiCheck').checked) {
            const period = parseInt(document.getElementById('rsiPeriod').value);
            indicators.rsi = this.calculateRSI(data, period);
        }
        
        // MACD
        if (document.getElementById('macdCheck').checked) {
            indicators.macd = this.calculateMACD(data);
        }
        
        // 布林通道
        if (document.getElementById('bbCheck').checked) {
            const period = parseInt(document.getElementById('bbPeriod').value);
            indicators.bb = this.calculateBollingerBands(data, period);
        }
        
        return indicators;
    }
    
    calculateSMA(data, period) {
        const sma = [];
        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                sma.push(null);
            } else {
                const sum = data.slice(i - period + 1, i + 1).reduce((acc, item) => acc + item.close, 0);
                sma.push(sum / period);
            }
        }
        return sma;
    }
    
    calculateEMA(data, period) {
        const ema = [];
        const multiplier = 2 / (period + 1);
        
        for (let i = 0; i < data.length; i++) {
            if (i === 0) {
                ema.push(data[i].close);
            } else {
                ema.push((data[i].close - ema[i - 1]) * multiplier + ema[i - 1]);
            }
        }
        return ema;
    }
    
    calculateRSI(data, period) {
        const rsi = [];
        const gains = [];
        const losses = [];
        
        for (let i = 1; i < data.length; i++) {
            const change = data[i].close - data[i - 1].close;
            gains.push(change > 0 ? change : 0);
            losses.push(change < 0 ? Math.abs(change) : 0);
        }
        
        for (let i = 0; i < data.length; i++) {
            if (i < period) {
                rsi.push(null);
            } else {
                const avgGain = gains.slice(i - period, i).reduce((a, b) => a + b, 0) / period;
                const avgLoss = losses.slice(i - period, i).reduce((a, b) => a + b, 0) / period;
                const rs = avgGain / avgLoss;
                rsi.push(100 - (100 / (1 + rs)));
            }
        }
        return rsi;
    }
    
    calculateMACD(data) {
        const closePrices = data.map(d => d.close);
        const ema12 = this.calculateEMAFromArray(closePrices, 12);
        const ema26 = this.calculateEMAFromArray(closePrices, 26);
        
        const macdLine = ema12.map((value, index) => {
            if (value && ema26[index]) {
                return value - ema26[index];
            }
            return null;
        });
        
        const signalLine = this.calculateEMAFromArray(macdLine.filter(v => v !== null), 9);
        
        // 填充信號線的 null 值
        const signalLineFilled = [];
        let signalIndex = 0;
        for (let i = 0; i < macdLine.length; i++) {
            if (macdLine[i] !== null) {
                signalLineFilled.push(signalLine[signalIndex] || 0);
                signalIndex++;
            } else {
                signalLineFilled.push(null);
            }
        }
        
        const histogram = macdLine.map((value, index) => {
            if (value !== null && signalLineFilled[index] !== null) {
                return value - signalLineFilled[index];
            }
            return null;
        });
        
        return {
            macd: macdLine,
            signal: signalLineFilled,
            histogram: histogram
        };
    }
    
    calculateEMAFromArray(values, period) {
        const ema = [];
        const multiplier = 2 / (period + 1);
        
        for (let i = 0; i < values.length; i++) {
            if (values[i] === null) {
                ema.push(null);
            } else if (i === 0 || ema[i - 1] === null) {
                ema.push(values[i]);
            } else {
                ema.push((values[i] - ema[i - 1]) * multiplier + ema[i - 1]);
            }
        }
        return ema;
    }
    
    calculateBollingerBands(data, period) {
        const sma = this.calculateSMA(data, period);
        const upper = [];
        const lower = [];
        
        for (let i = 0; i < data.length; i++) {
            if (i < period - 1) {
                upper.push(null);
                lower.push(null);
            } else {
                const slice = data.slice(i - period + 1, i + 1);
                const mean = sma[i];
                const variance = slice.reduce((acc, item) => acc + Math.pow(item.close - mean, 2), 0) / period;
                const stdDev = Math.sqrt(variance);
                upper.push(mean + (stdDev * 2));
                lower.push(mean - (stdDev * 2));
            }
        }
        
        return { upper, middle: sma, lower };
    }
    
    calculateSMCAnalysis(data) {
        const analysis = {
            overallBias: '中性',
            description: '分析市場結構和關鍵價位',
            keyAreas: []
        };
        
        if (data.length < 50) {
            analysis.description = '數據不足，無法進行完整分析';
            return analysis;
        }
        
        // 找出近期的高低點
        const recentData = data.slice(-30);
        const highs = [];
        const lows = [];
        
        for (let i = 1; i < recentData.length - 1; i++) {
            if (recentData[i].high > recentData[i-1].high && recentData[i].high > recentData[i+1].high) {
                highs.push({ price: recentData[i].high, index: i });
            }
            if (recentData[i].low < recentData[i-1].low && recentData[i].low < recentData[i+1].low) {
                lows.push({ price: recentData[i].low, index: i });
            }
        }
        
        // 找出支撐阻力位
        const currentPrice = data[data.length - 1].close;
        const sortedHighs = highs.sort((a, b) => b.price - a.price);
        const sortedLows = lows.sort((a, b) => a.price - b.price);
        
        // 最近的阻力位
        const nearestResistance = sortedHighs.find(h => h.price > currentPrice);
        if (nearestResistance) {
            analysis.keyAreas.push({
                type: '阻力位',
                price: nearestResistance.price,
                description: '上方主要阻力區域'
            });
        }
        
        // 最近的支撐位
        const nearestSupport = sortedLows.find(l => l.price < currentPrice);
        if (nearestSupport) {
            analysis.keyAreas.push({
                type: '支撐位',
                price: nearestSupport.price,
                description: '下方主要支撐區域'
            });
        }
        
        // 分析市場結構
        if (highs.length >= 2 && lows.length >= 2) {
            const lastHigh = highs[highs.length - 1];
            const lastLow = lows[lows.length - 1];
            
            if (lastHigh.price > highs[highs.length - 2].price && lastLow.price > lows[lows.length - 2].price) {
                analysis.overallBias = '看漲';
                analysis.description = '高點和低點都在上升，形成上升趨勢';
            } else if (lastHigh.price < highs[highs.length - 2].price && lastLow.price < lows[lows.length - 2].price) {
                analysis.overallBias = '看跌';
                analysis.description = '高點和低點都在下降，形成下降趨勢';
            } else {
                analysis.overallBias = '震盪';
                analysis.description = '市場處於震盪整理階段';
            }
        }
        
        // 添加流動性區域分析
        const volumeData = data.slice(-20);
        const avgVolume = volumeData.reduce((sum, item) => sum + item.volume, 0) / volumeData.length;
        const currentVolume = data[data.length - 1].volume;
        
        if (currentVolume > avgVolume * 1.5) {
            analysis.keyAreas.push({
                type: '流動性區域',
                price: currentPrice,
                description: '成交量放大，可能有大資金活動'
            });
        }
        
        return analysis;
    }
    
    generateTradingSignals(data, indicators) {
        const signals = {
            buySignals: [],
            sellSignals: [],
            marketBias: 'neutral',
            keyLevels: [],
            overallSignal: '中性',
            trendSignals: [],
            indicatorSignals: [],
            riskWarnings: []
        };
        
        const latest = data[data.length - 1];
        
        // RSI 信號
        if (indicators.rsi) {
            const currentRSI = indicators.rsi[indicators.rsi.length - 1];
            if (currentRSI > 70) {
                signals.sellSignals.push('RSI超買區域，考慮賣出');
                signals.overallSignal = '賣出';
            } else if (currentRSI < 30) {
                signals.buySignals.push('RSI超賣區域，考慮買入');
                signals.overallSignal = '買入';
            }
        }
        
        // MACD 信號
        if (indicators.macd) {
            const macdLine = indicators.macd.macd[indicators.macd.macd.length - 1];
            const signalLine = indicators.macd.signal[indicators.macd.signal.length - 1];
            if (macdLine > signalLine) {
                signals.buySignals.push('MACD黃金交叉，看漲信號');
                signals.overallSignal = '買入';
            } else {
                signals.sellSignals.push('MACD死亡交叉，看跌信號');
                signals.overallSignal = '賣出';
            }
        }
        
        // 移動平均線信號
        if (indicators.sma) {
            const currentSMA = indicators.sma[indicators.sma.length - 1];
            if (latest.close > currentSMA) {
                signals.buySignals.push('價格高於SMA，趨勢看漲');
                signals.trendSignals.push({ type: '買入', description: '價格高於SMA，趨勢看漲' });
            } else {
                signals.sellSignals.push('價格低於SMA，趨勢看跌');
                signals.trendSignals.push({ type: '賣出', description: '價格低於SMA，趨勢看跌' });
            }
        }
        
        // 布林通道信號
        if (indicators.bb) {
            const currentUpper = indicators.bb.upper[indicators.bb.upper.length - 1];
            const currentLower = indicators.bb.lower[indicators.bb.lower.length - 1];
            if (latest.close >= currentUpper) {
                signals.sellSignals.push('價格觸及布林上軌，可能回調');
                signals.trendSignals.push({ type: '賣出', description: '價格觸及布林上軌，可能回調' });
            } else if (latest.close <= currentLower) {
                signals.buySignals.push('價格觸及布林下軌，可能反彈');
                signals.trendSignals.push({ type: '買入', description: '價格觸及布林下軌，可能反彈' });
            }
        }
        
        // 計算支撐阻力位
        const highs = data.slice(-20).map(d => d.high);
        const lows = data.slice(-20).map(d => d.low);
        signals.keyLevels.push({
            type: '阻力',
            price: Math.max(...highs),
            description: '近期高點阻力位'
        });
        signals.keyLevels.push({
            type: '支撐',
            price: Math.min(...lows),
            description: '近期低點支撐位'
        });
        
        // 技術指標信號
        if (indicators.sma) {
            const smaValue = indicators.sma[indicators.sma.length - 1];
            if (smaValue) {
                const trend = latest.close > smaValue ? '買入' : '賣出';
                signals.trendSignals.push({ type: trend, description: `SMA(${document.getElementById('smaPeriod').value})` });
                signals.indicatorSignals.push({ type: trend, description: `SMA(${document.getElementById('smaPeriod').value})` });
            }
        }
        
        if (indicators.ema) {
            const emaValue = indicators.ema[indicators.ema.length - 1];
            if (emaValue) {
                const trend = latest.close > emaValue ? '買入' : '賣出';
                signals.trendSignals.push({ type: trend, description: `EMA(${document.getElementById('emaPeriod').value})` });
                signals.indicatorSignals.push({ type: trend, description: `EMA(${document.getElementById('emaPeriod').value})` });
            }
        }
        
        if (indicators.rsi) {
            const rsiValue = indicators.rsi[indicators.rsi.length - 1];
            if (rsiValue) {
                let status = '';
                let color = '';
                if (rsiValue > 70) {
                    status = '超買';
                    color = 'price-change-negative';
                    signals.riskWarnings.push('RSI超買區域，可能回調');
                } else if (rsiValue < 30) {
                    status = '超賣';
                    color = 'price-change-positive';
                    signals.riskWarnings.push('RSI超賣區域，可能反彈');
                } else {
                    status = '中性';
                    color = '';
                }
                signals.indicatorSignals.push({ type: status, description: `RSI(${document.getElementById('rsiPeriod').value})` });
            }
        }
        
        if (indicators.macd) {
            const macd = indicators.macd;
            const macdValue = macd.macd[macd.macd.length - 1];
            const signalValue = macd.signal[macd.signal.length - 1];
            const histogramValue = macd.histogram[macd.histogram.length - 1];
            
            if (macdValue && signalValue) {
                const trend = macdValue > signalValue ? '買入' : '賣出';
                signals.trendSignals.push({ type: trend, description: 'MACD' });
                signals.indicatorSignals.push({ type: trend, description: 'MACD' });
            }
        }
        
        if (indicators.bb) {
            const bb = indicators.bb;
            const upper = bb.upper[bb.upper.length - 1];
            const middle = bb.middle[bb.middle.length - 1];
            const lower = bb.lower[bb.lower.length - 1];
            
            let bbStatus = '';
            let bbColor = '';
            if (latest.close > upper) {
                bbStatus = '突破上軌';
                bbColor = 'price-change-negative';
                signals.riskWarnings.push('價格突破布林上軌，可能回調');
            } else if (latest.close < lower) {
                bbStatus = '突破下軌';
                bbColor = 'price-change-positive';
                signals.riskWarnings.push('價格突破布林下軌，可能反彈');
            } else {
                bbStatus = '通道內';
                bbColor = '';
            }
            
            signals.indicatorSignals.push({ type: bbStatus, description: '布林通道' });
        }
        
        return signals;
    }
    
    async updateData() {
        try {
            console.log('updateData: 開始更新數據');
            
            // 顯示加載狀態
            const statusElement = document.getElementById('updateStatus');
            if (statusElement) {
                statusElement.textContent = '正在更新數據...';
                statusElement.style.display = 'block';
            }
            
            const symbol = document.getElementById('symbolSelect').value;
            const timeframe = document.getElementById('timeframeSelect').value;
            
            console.log(`updateData: 獲取 ${symbol} 的 ${timeframe} 數據`);
            
            // 更新當前配對顯示
            document.getElementById('currentPair').textContent = 
                `${this.cryptoNames[symbol]} - ${this.timeframes[timeframe]}`;
            
            // 獲取新數據
            const newData = await this.fetchBinanceData(symbol, timeframe);
            
            if (newData && newData.length > 0) {
                console.log(`updateData: 成功獲取 ${newData.length} 個數據點`);
                
                this.currentData = newData;
                this.currentIndicators = this.calculateIndicators(newData);
                
                // 更新圖表
                this.updateChart();
                
                // 更新市場信息
                this.updateMarketInfo();
                
                // 更新指標數值
                this.updateIndicatorValues();
                
                // 更新交易信號
                this.updateTradingSignals();
                
                // 更新最後更新時間
                this.updateLastUpdateTime();
                
                console.log('updateData: 數據更新完成');
            } else {
                console.error('updateData: 獲取數據失敗 - 數據為空');
                throw new Error('無法獲取數據');
            }
        } catch (error) {
            console.error('updateData: 更新數據時發生錯誤:', error);
            
            // 顯示網路連線錯誤訊息
            this.showNetworkError();
            
            // 顯示錯誤狀態
            const statusElement = document.getElementById('updateStatus');
            if (statusElement) {
                statusElement.innerHTML = `
                    <span style="color: #ff4757;">⚠️ 網路連線問題，無法顯示即時數據</span>
                    <br>
                    <span style="font-size: 12px; color: #888;">使用模擬數據進行展示</span>
                `;
                statusElement.style.display = 'block';
            }
        }
    }
    
    switchChart(chartType) {
        console.log(`切換到 ${chartType} 圖表`);
        
        // 更新按鈕狀態
        document.getElementById('plotlyChartBtn').classList.toggle('active', chartType === 'plotly');
        document.getElementById('tradingviewChartBtn').classList.toggle('active', chartType === 'tradingview');
        
        // 更新容器顯示狀態
        document.getElementById('plotlyChartContainer').classList.toggle('active', chartType === 'plotly');
        document.getElementById('tradingviewChartContainer').classList.toggle('active', chartType === 'tradingview');
        
        // 根據圖表類型重新渲染
        if (chartType === 'plotly') {
            console.log('重新渲染 Plotly 圖表');
            this.updateChart();
        }
    }
    
    updateChart() {
        if (!this.currentData) {
            console.log('updateChart: 沒有數據，跳過渲染');
            return;
        }
        
        console.log('updateChart: 開始渲染圖表，數據點數量:', this.currentData.length);
        
        const data = this.currentData;
        const indicators = this.currentIndicators;
        
        // 準備蠟燭圖數據
        const candlestickTrace = {
            x: data.map(d => d.timestamp),
            open: data.map(d => d.open),
            high: data.map(d => d.high),
            low: data.map(d => d.low),
            close: data.map(d => d.close),
            type: 'candlestick',
            name: '價格',
            increasing: { line: { color: '#00d4aa' } },
            decreasing: { line: { color: '#ff4757' } }
        };
        
        const traces = [candlestickTrace];
        console.log('updateChart: 蠟燭圖數據準備完成');
        
        // 添加技術指標
        if (indicators.sma) {
            traces.push({
                x: data.map(d => d.timestamp),
                y: indicators.sma,
                type: 'scatter',
                mode: 'lines',
                name: `SMA(${document.getElementById('smaPeriod').value})`,
                line: { color: '#ffa502', width: 2 }
            });
            console.log('updateChart: SMA 指標已添加');
        }
        
        if (indicators.ema) {
            traces.push({
                x: data.map(d => d.timestamp),
                y: indicators.ema,
                type: 'scatter',
                mode: 'lines',
                name: `EMA(${document.getElementById('emaPeriod').value})`,
                line: { color: '#3742fa', width: 2 }
            });
            console.log('updateChart: EMA 指標已添加');
        }
        
        if (indicators.bb) {
            traces.push({
                x: data.map(d => d.timestamp),
                y: indicators.bb.upper,
                type: 'scatter',
                mode: 'lines',
                name: '布林上軌',
                line: { color: '#7bed9f', width: 1 }
            });
            traces.push({
                x: data.map(d => d.timestamp),
                y: indicators.bb.middle,
                type: 'scatter',
                mode: 'lines',
                name: '布林中軌',
                line: { color: '#70a1ff', width: 1, dash: 'dash' }
            });
            traces.push({
                x: data.map(d => d.timestamp),
                y: indicators.bb.lower,
                type: 'scatter',
                mode: 'lines',
                name: '布林下軌',
                line: { color: '#7bed9f', width: 1 }
            });
            console.log('updateChart: 布林通道指標已添加');
        }
        
        console.log('updateChart: 準備渲染圖表，trace 數量:', traces.length);
        
        // 佈局設置
        const layout = {
            title: {
                text: document.getElementById('currentPair').textContent,
                font: { color: '#fafafa' }
            },
            paper_bgcolor: '#262730',
            plot_bgcolor: '#262730',
            font: { color: '#fafafa' },
            xaxis: {
                title: '時間',
                gridcolor: 'rgba(128,128,128,0.2)',
                rangeslider: { visible: false }
            },
            yaxis: {
                title: '價格 (USDT)',
                gridcolor: 'rgba(128,128,128,0.2)'
            },
            showlegend: true,
            legend: {
                orientation: 'h',
                y: 1.02,
                x: 0
            },
            margin: { t: 80, b: 50, l: 60, r: 60 },
            autosize: true,
            height: 500,
            annotations: [
                {
                    x: 1,
                    y: 0,
                    xref: 'paper',
                    yref: 'paper',
                    text: '數據來源：幣安官方API',
                    showarrow: false,
                    xanchor: 'right',
                    yanchor: 'bottom',
                    font: {
                        size: 10,
                        color: 'rgba(255, 255, 255, 0.6)'
                    },
                    bgcolor: 'rgba(0, 0, 0, 0.3)',
                    bordercolor: 'rgba(255, 255, 255, 0.2)',
                    borderwidth: 1
                }
            ]
        };
        
        // 創建圖表 - 現在渲染到 plotlyChartContainer
        console.log('updateChart: 開始渲染 Plotly 圖表');
        
        // 確保容器存在
        const container = document.getElementById('plotlyChartContainer');
        if (!container) {
            console.error('updateChart: 找不到圖表容器');
            return;
        }
        
        Plotly.newPlot('plotlyChartContainer', traces, layout, {
            responsive: true,
            displayModeBar: false,
            staticPlot: false
        }).then(() => {
            console.log('updateChart: 圖表渲染完成');
            
            // 隱藏加載提示
            const loadingElement = document.querySelector('#plotlyChartContainer .loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
                console.log('updateChart: 加載提示已隱藏');
            }
            
            // 顯示更新狀態
            const statusElement = document.getElementById('updateStatus');
            if (statusElement) {
                statusElement.style.display = 'block';
            }
            
            // 添加關鍵價位標記
            setTimeout(() => {
                this.addKeyLevelsToChart();
            }, 100);
        }).catch(error => {
            console.error('updateChart: 圖表渲染失敗:', error);
            
            // 隱藏加載提示
            const loadingElement = document.querySelector('#plotlyChartContainer .loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            
            // 顯示錯誤信息
            const container = document.getElementById('plotlyChartContainer');
            if (container) {
                container.innerHTML = `
                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #ff4757;">
                        <div style="text-align: center;">
                            <h3>圖表渲染失敗</h3>
                            <p>${error.message}</p>
                            <button onclick="location.reload()" style="margin-top: 10px; padding: 8px 16px; background: #00d4aa; border: none; border-radius: 4px; color: white; cursor: pointer;">
                                重新載入
                            </button>
                        </div>
                    </div>
                `;
            }
        });
    }
    
    addKeyLevelsToChart() {
        if (!this.currentData || !this.currentIndicators) return;
        
        const latest = this.currentData[this.currentData.length - 1];
        const annotations = [];
        
        // 根據選中的指標添加關鍵價位
        if (document.getElementById('smaCheck').checked && this.currentIndicators.sma) {
            const smaValue = this.currentIndicators.sma[this.currentIndicators.sma.length - 1];
            if (smaValue) {
                annotations.push({
                    x: latest.timestamp,
                    y: smaValue,
                    text: `SMA(${document.getElementById('smaPeriod').value})`,
                    showarrow: true,
                    arrowhead: 2,
                    arrowsize: 1,
                    arrowwidth: 2,
                    arrowcolor: '#ffa502',
                    ax: 0,
                    ay: -40,
                    bgcolor: 'rgba(255, 165, 2, 0.8)',
                    bordercolor: '#ffa502',
                    borderwidth: 1,
                    font: { color: '#fff', size: 12 }
                });
            }
        }
        
        if (document.getElementById('emaCheck').checked && this.currentIndicators.ema) {
            const emaValue = this.currentIndicators.ema[this.currentIndicators.ema.length - 1];
            if (emaValue) {
                annotations.push({
                    x: latest.timestamp,
                    y: emaValue,
                    text: `EMA(${document.getElementById('emaPeriod').value})`,
                    showarrow: true,
                    arrowhead: 2,
                    arrowsize: 1,
                    arrowwidth: 2,
                    arrowcolor: '#3742fa',
                    ax: 0,
                    ay: 40,
                    bgcolor: 'rgba(55, 66, 250, 0.8)',
                    bordercolor: '#3742fa',
                    borderwidth: 1,
                    font: { color: '#fff', size: 12 }
                });
            }
        }
        
        if (document.getElementById('bbCheck').checked && this.currentIndicators.bb) {
            const bb = this.currentIndicators.bb;
            const upper = bb.upper[bb.upper.length - 1];
            const lower = bb.lower[bb.lower.length - 1];
            
            if (upper) {
                annotations.push({
                    x: latest.timestamp,
                    y: upper,
                    text: '布林上軌',
                    showarrow: true,
                    arrowhead: 2,
                    arrowsize: 1,
                    arrowwidth: 2,
                    arrowcolor: '#7bed9f',
                    ax: 0,
                    ay: -60,
                    bgcolor: 'rgba(123, 237, 159, 0.8)',
                    bordercolor: '#7bed9f',
                    borderwidth: 1,
                    font: { color: '#fff', size: 12 }
                });
            }
            
            if (lower) {
                annotations.push({
                    x: latest.timestamp,
                    y: lower,
                    text: '布林下軌',
                    showarrow: true,
                    arrowhead: 2,
                    arrowsize: 1,
                    arrowwidth: 2,
                    arrowcolor: '#7bed9f',
                    ax: 0,
                    ay: 60,
                    bgcolor: 'rgba(123, 237, 159, 0.8)',
                    bordercolor: '#7bed9f',
                    borderwidth: 1,
                    font: { color: '#fff', size: 12 }
                });
            }
        }
        
        // 更新圖表註釋
        if (annotations.length > 0) {
            console.log('addKeyLevelsToChart: 添加關鍵價位標記', annotations.length, '個');
            Plotly.relayout('plotlyChartContainer', {
                annotations: annotations
            }).then(() => {
                console.log('addKeyLevelsToChart: 關鍵價位標記添加完成');
            }).catch(error => {
                console.error('addKeyLevelsToChart: 添加關鍵價位標記失敗:', error);
            });
        } else {
            console.log('addKeyLevelsToChart: 沒有選中的指標，跳過關鍵價位標記');
        }
    }
    
    updateMarketInfo() {
        if (!this.currentData) return;
        
        const latest = this.currentData[this.currentData.length - 1];
        const previous = this.currentData[this.currentData.length - 2];
        const priceChange = latest.close - previous.close;
        const priceChangePercent = (priceChange / previous.close) * 100;
        
        // 計算24小時變化（使用前24個數據點）
        const dayAgo = this.currentData[Math.max(0, this.currentData.length - 24)];
        const dayChange = latest.close - dayAgo.close;
        const dayChangePercent = (dayChange / dayAgo.close) * 100;
        
        const marketData = document.getElementById('marketData');
        marketData.innerHTML = `
            <div class="price-metric">
                <span class="metric-label">當前價格</span>
                <span class="metric-value ${priceChange >= 0 ? 'price-change-positive' : 'price-change-negative'}">
                    $${latest.close.toFixed(2)}
                </span>
            </div>
            <div class="price-metric">
                <span class="metric-label">24h變化</span>
                <span class="metric-value ${dayChange >= 0 ? 'price-change-positive' : 'price-change-negative'}">
                    ${dayChange >= 0 ? '+' : ''}${dayChange.toFixed(2)} (${dayChangePercent >= 0 ? '+' : ''}${dayChangePercent.toFixed(2)}%)
                </span>
            </div>
            <div class="price-metric">
                <span class="metric-label">開盤價</span>
                <span class="metric-value">$${latest.open.toFixed(2)}</span>
            </div>
            <div class="price-metric">
                <span class="metric-label">最高價</span>
                <span class="metric-value">$${latest.high.toFixed(2)}</span>
            </div>
            <div class="price-metric">
                <span class="metric-label">最低價</span>
                <span class="metric-value">$${latest.low.toFixed(2)}</span>
            </div>
            <div class="price-metric">
                <span class="metric-label">成交量</span>
                <span class="metric-value">${latest.volume.toLocaleString()}</span>
            </div>
        `;
    }
    
    updateIndicatorValues() {
        if (!this.currentIndicators) return;
        
        let html = '<div class="indicator-intro">技術指標數值說明：</div>';
        
        if (this.currentIndicators.sma) {
            const value = this.currentIndicators.sma[this.currentIndicators.sma.length - 1];
            if (value) {
                const currentPrice = this.currentData[this.currentData.length - 1].close;
                const trend = currentPrice > value ? '看漲' : '看跌';
                const trendColor = currentPrice > value ? 'price-change-positive' : 'price-change-negative';
                html += `<div class="price-metric">
                    <div class="metric-row">
                        <span class="metric-label">SMA(${document.getElementById('smaPeriod').value})</span>
                        <span class="metric-value">$${value.toFixed(2)}</span>
                        <span class="metric-trend ${trendColor}">${trend}</span>
                    </div>
                    <div class="metric-desc">簡單移動平均線：過去${document.getElementById('smaPeriod').value}個週期的平均收盤價</div>
                </div>`;
            }
        }
        
        if (this.currentIndicators.ema) {
            const value = this.currentIndicators.ema[this.currentIndicators.ema.length - 1];
            const currentPrice = this.currentData[this.currentData.length - 1].close;
            const trend = currentPrice > value ? '看漲' : '看跌';
            const trendColor = currentPrice > value ? 'price-change-positive' : 'price-change-negative';
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">EMA(${document.getElementById('emaPeriod').value})</span>
                    <span class="metric-value">$${value.toFixed(2)}</span>
                    <span class="metric-trend ${trendColor}">${trend}</span>
                </div>
                <div class="metric-desc">指數移動平均線：對近期價格給予更高權重的移動平均線</div>
            </div>`;
        }
        
        if (this.currentIndicators.rsi) {
            const value = this.currentIndicators.rsi[this.currentIndicators.rsi.length - 1];
            if (value) {
                let status = '';
                let color = '';
                if (value > 70) {
                    status = '超買';
                    color = 'price-change-negative';
                } else if (value < 30) {
                    status = '超賣';
                    color = 'price-change-positive';
                } else {
                    status = '中性';
                    color = '';
                }
                html += `<div class="price-metric">
                    <div class="metric-row">
                        <span class="metric-label">RSI(${document.getElementById('rsiPeriod').value})</span>
                        <span class="metric-value ${color}">${value.toFixed(2)}</span>
                        <span class="metric-trend ${color}">${status}</span>
                    </div>
                    <div class="metric-desc">相對強弱指標：衡量價格變動的速度和幅度，0-100範圍</div>
                </div>`;
            }
        }
        
        if (this.currentIndicators.macd) {
            const macd = this.currentIndicators.macd;
            const macdValue = macd.macd[macd.macd.length - 1];
            const signalValue = macd.signal[macd.signal.length - 1];
            const histogramValue = macd.histogram[macd.histogram.length - 1];
            
            if (macdValue && signalValue) {
                const trend = macdValue > signalValue ? '看漲' : '看跌';
                const trendColor = macdValue > signalValue ? 'price-change-positive' : 'price-change-negative';
                html += `<div class="price-metric">
                    <div class="metric-row">
                        <span class="metric-label">MACD</span>
                        <span class="metric-value">${macdValue.toFixed(4)}</span>
                        <span class="metric-trend ${trendColor}">${trend}</span>
                    </div>
                    <div class="metric-desc">MACD線：12日EMA減去26日EMA的差值</div>
                </div>`;
                html += `<div class="price-metric">
                    <div class="metric-row">
                        <span class="metric-label">信號線</span>
                        <span class="metric-value">${signalValue.toFixed(4)}</span>
                    </div>
                    <div class="metric-desc">MACD的9日EMA，用於產生買賣信號</div>
                </div>`;
                html += `<div class="price-metric">
                    <div class="metric-row">
                        <span class="metric-label">柱狀圖</span>
                        <span class="metric-value ${histogramValue >= 0 ? 'price-change-positive' : 'price-change-negative'}">${histogramValue.toFixed(4)}</span>
                    </div>
                    <div class="metric-desc">MACD線減去信號線，顯示動量變化</div>
                </div>`;
            }
        }
        
        if (this.currentIndicators.bb) {
            const bb = this.currentIndicators.bb;
            const upper = bb.upper[bb.upper.length - 1];
            const middle = bb.middle[bb.middle.length - 1];
            const lower = bb.lower[bb.lower.length - 1];
            const currentPrice = this.currentData[this.currentData.length - 1].close;
            
            let bbStatus = '';
            let bbColor = '';
            if (currentPrice > upper) {
                bbStatus = '突破上軌';
                bbColor = 'price-change-negative';
            } else if (currentPrice < lower) {
                bbStatus = '突破下軌';
                bbColor = 'price-change-positive';
            } else {
                bbStatus = '通道內';
                bbColor = '';
            }
            
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">布林上軌</span>
                    <span class="metric-value">$${upper.toFixed(2)}</span>
                </div>
                <div class="metric-desc">中軌 + (2 × 標準差)，阻力位</div>
            </div>`;
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">布林中軌</span>
                    <span class="metric-value">$${middle.toFixed(2)}</span>
                </div>
                <div class="metric-desc">${document.getElementById('bbPeriod').value}日簡單移動平均線</div>
            </div>`;
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">布林下軌</span>
                    <span class="metric-value">$${lower.toFixed(2)}</span>
                </div>
                <div class="metric-desc">中軌 - (2 × 標準差)，支撐位</div>
            </div>`;
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">布林狀態</span>
                    <span class="metric-trend ${bbColor}">${bbStatus}</span>
                </div>
                <div class="metric-desc">價格相對於布林通道的位置</div>
            </div>`;
        }
        
        // 成交量顯示
        if (document.getElementById('volumeCheck').checked) {
            const latest = this.currentData[this.currentData.length - 1];
            const avgVolume = this.currentData.slice(-20).reduce((sum, item) => sum + item.volume, 0) / 20;
            const volumeRatio = latest.volume / avgVolume;
            let volumeStatus = '';
            let volumeColor = '';
            
            if (volumeRatio > 1.5) {
                volumeStatus = '放量';
                volumeColor = 'price-change-positive';
            } else if (volumeRatio < 0.5) {
                volumeStatus = '縮量';
                volumeColor = 'price-change-negative';
            } else {
                volumeStatus = '正常';
                volumeColor = '';
            }
            
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">成交量</span>
                    <span class="metric-value">${latest.volume.toLocaleString()}</span>
                    <span class="metric-trend ${volumeColor}">${volumeStatus}</span>
                </div>
                <div class="metric-desc">當前成交量與20期平均成交量比較</div>
            </div>`;
        }
        
        // SMC 智能資金概念分析
        if (document.getElementById('smcCheck').checked) {
            const smcAnalysis = this.calculateSMCAnalysis(this.currentData);
            html += `<div class="price-metric">
                <div class="metric-row">
                    <span class="metric-label">SMC 分析</span>
                    <span class="metric-trend">${smcAnalysis.overallBias}</span>
                </div>
                <div class="metric-desc">智能資金概念分析：${smcAnalysis.description}</div>
            </div>`;
            
            // 顯示 SMC 關鍵區域
            if (smcAnalysis.keyAreas.length > 0) {
                html += `<div class="smc-areas">
                    <div class="metric-desc">關鍵區域：</div>`;
                smcAnalysis.keyAreas.forEach(area => {
                    html += `<div class="smc-area">
                        <span class="area-type">${area.type}</span>
                        <span class="area-price">$${area.price.toFixed(2)}</span>
                        <span class="area-desc">${area.description}</span>
                    </div>`;
                });
                html += `</div>`;
            }
        }
        
        const indicatorValues = document.getElementById('indicatorValues');
        indicatorValues.innerHTML = html;
    }
    
    updateTradingSignals() {
        if (!this.currentData || !this.currentIndicators) return;
        
        const signals = this.generateTradingSignals(this.currentData, this.currentIndicators);
        let html = '';
        
        // 綜合信號
        const overallSignal = signals.overallSignal;
        const overallColor = overallSignal === '買入' ? 'signal-buy' : 
                           overallSignal === '賣出' ? 'signal-sell' : 'signal-neutral';
        
        html += `<div class="signal-item ${overallColor}">
            <span class="signal-label">綜合信號</span>
            <span class="signal-value">${overallSignal}</span>
        </div>`;
        
        // 趨勢信號
        if (signals.trendSignals.length > 0) {
            html += `<div class="signal-item">
                <span class="signal-label">趨勢分析</span>
            </div>`;
            signals.trendSignals.forEach(signal => {
                const color = signal.type === '買入' ? 'signal-buy' : 
                            signal.type === '賣出' ? 'signal-sell' : 'signal-neutral';
                html += `<div class="signal-item ${color}">
                    <span class="signal-value">${signal.description}</span>
                </div>`;
            });
        }
        
        // 支撐阻力位
        if (signals.keyLevels.length > 0) {
            html += `<div class="signal-item">
                <span class="signal-label">關鍵價位</span>
            </div>`;
            signals.keyLevels.forEach(level => {
                html += `<div class="signal-item signal-neutral">
                    <span class="signal-value">${level.type}: $${level.price.toFixed(2)}</span>
                    <span class="signal-desc">${level.description}</span>
                </div>`;
            });
        }
        
        // 技術指標信號
        if (signals.indicatorSignals.length > 0) {
            html += `<div class="signal-item">
                <span class="signal-label">指標信號</span>
            </div>`;
            signals.indicatorSignals.forEach(signal => {
                const color = signal.type === '買入' ? 'signal-buy' : 
                            signal.type === '賣出' ? 'signal-sell' : 'signal-neutral';
                html += `<div class="signal-item ${color}">
                    <span class="signal-value">${signal.description}</span>
                </div>`;
            });
        }
        
        // 風險警告
        if (signals.riskWarnings.length > 0) {
            html += `<div class="signal-item">
                <span class="signal-label">風險提示</span>
            </div>`;
            signals.riskWarnings.forEach(warning => {
                html += `<div class="signal-item signal-neutral">
                    <span class="signal-value">⚠️ ${warning}</span>
                </div>`;
            });
        }
        
        const tradingSignals = document.getElementById('tradingSignals');
        tradingSignals.innerHTML = html;
    }
    
    startAutoRefresh() {
        // 每5分鐘自動刷新
        this.refreshInterval = setInterval(() => {
            console.log('自動更新數據...');
            this.updateData();
        }, 300000); // 300秒 = 5分鐘
        
        // 立即更新一次
        this.updateLastUpdateTime();
    }
    
    updateLastUpdateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-TW');
        const dateString = now.toLocaleDateString('zh-TW');
        
        // 更新狀態顯示
        const statusElement = document.getElementById('updateStatus');
        if (statusElement) {
            statusElement.textContent = `最後更新: ${dateString} ${timeString} (每5分鐘更新)`;
        }
    }
    
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
    }
    
    async fetchTradingViewData(symbol, timeframe) {
        try {
            // 使用幣安 API 獲取數據，因為 TradingView 小工具本身不提供數據 API
            const binanceSymbol = symbol.replace('USDT', 'USDT');
            const binanceTimeframe = this.convertTimeframeToBinance(timeframe);
            
            const url = `https://api.binance.com/api/v3/klines?symbol=${binanceSymbol}&interval=${binanceTimeframe}&limit=500`;
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`API request failed: ${response.status}`);
            }
            
            const rawData = await response.json();
            
            // 檢查是否為錯誤響應
            if (rawData.code && rawData.msg) {
                throw new Error(`Binance API error: ${rawData.msg}`);
            }
            
            // 轉換幣安數據格式
            const data = rawData.map(item => ({
                timestamp: new Date(item[0]), // 開盤時間
                open: parseFloat(item[1]),
                high: parseFloat(item[2]),
                low: parseFloat(item[3]),
                close: parseFloat(item[4]),
                volume: parseFloat(item[5])
            }));
            
            return data;
        } catch (error) {
            console.error('獲取 TradingView 數據失敗:', error);
            throw error;
        }
    }
    
    convertTimeframeToBinance(timeframe) {
        const mapping = {
            '1m': '1m',
            '5m': '5m',
            '15m': '15m',
            '1h': '1h',
            '4h': '4h',
            '1d': '1d'
        };
        return mapping[timeframe] || '1h';
    }
    
    showNetworkError() {
        // 創建錯誤提示元素
        const errorContainer = document.createElement('div');
        errorContainer.id = 'networkErrorContainer';
        errorContainer.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #ff4757, #ff3742);
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(255, 71, 87, 0.3);
            z-index: 1000;
            max-width: 300px;
            font-family: 'Microsoft JhengHei', sans-serif;
            animation: slideInRight 0.3s ease-out;
        `;
        
        errorContainer.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <div style="font-size: 20px;">⚠️</div>
                <div>
                    <div style="font-weight: bold; margin-bottom: 5px;">網路連線問題</div>
                    <div style="font-size: 14px; opacity: 0.9;">無法連接到幣安 API，使用模擬數據</div>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" 
                        style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; margin-left: 10px;">
                    ×
                </button>
            </div>
        `;
        
        // 添加動畫樣式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
        
        // 添加到頁面
        document.body.appendChild(errorContainer);
        
        // 5秒後自動移除
        setTimeout(() => {
            if (errorContainer.parentElement) {
                errorContainer.remove();
            }
        }, 5000);
        
        // 更新狀態顯示
        const statusElement = document.getElementById('updateStatus');
        if (statusElement) {
            statusElement.innerHTML = `
                <span style="color: #ff4757;">⚠️ 網路連線問題，無法顯示即時數據</span>
                <br>
                <span style="font-size: 12px; color: #888;">使用模擬數據進行展示</span>
            `;
        }
        
        // 更新圖表容器顯示
        const plotlyContainer = document.getElementById('plotlyChartContainer');
        if (plotlyContainer) {
            const existingError = plotlyContainer.querySelector('.network-error-notice');
            if (!existingError) {
                const errorNotice = document.createElement('div');
                errorNotice.className = 'network-error-notice';
                errorNotice.style.cssText = `
                    background: rgba(255, 71, 87, 0.1);
                    border: 1px solid rgba(255, 71, 87, 0.3);
                    border-radius: 6px;
                    padding: 10px;
                    margin-bottom: 15px;
                    color: #ff4757;
                    font-size: 14px;
                    text-align: center;
                `;
                errorNotice.innerHTML = `
                    <strong>⚠️ 網路連線問題</strong><br>
                    無法連接到幣安 API，目前顯示模擬數據
                `;
                plotlyContainer.insertBefore(errorNotice, plotlyContainer.firstChild);
            }
        }
    }
}

// 初始化應用程式
document.addEventListener('DOMContentLoaded', () => {
    new CryptoAnalysisPlatform();
});